
class Course {
  final String name;
  const Course({required this.name});
}
class StudentScore{
  
  final String name; 
  final  double score;
  const StudentScore({required this.name,required this.score});
}