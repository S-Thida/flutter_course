import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_charts/charts.dart';
import '../../models/expense.dart'; // Ensure your Expense model includes 'amount' and 'date'
import 'expenses_form.dart';
import 'expenses_list.dart';

class Expenses extends StatefulWidget {
  const Expenses({super.key});

  @override
  State<Expenses> createState() {
    return _ExpensesState();
  }
}

class _ExpensesState extends State<Expenses> {
  final List<Expense> _registeredExpenses = [];
  double _currentBalance = 1000.0; // Example starting balance

  void onExpenseRemoved(Expense expense) {
    setState(() {
      _registeredExpenses.remove(expense);
      _currentBalance +=
          expense.amount; // Increase balance when expense is removed
    });
  }

  void onExpenseCreated(Expense newExpense) {
    if (newExpense.amount > _currentBalance) {
      // Show alert if the expense exceeds the current balance
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Insufficient Balance'),
          content: const Text('Current balance is not enough.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(),
              child: const Text('Okay'),
            ),
          ],
        ),
      );
      return;
    }

    setState(() {
      _registeredExpenses.add(newExpense);
      _currentBalance -=
          newExpense.amount; // Decrease balance when expense is added
    });
  }

  void onAddPressed() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => ExpenseForm(onCreated: onExpenseCreated),
    );
  }

  List<ChartData> getChartData() {
    // Group expenses by day and create chart data
    Map<String, double> dailyExpenses = {};
    for (var expense in _registeredExpenses) {
      // Only use the year, month, and day to compare dates
      String dateKey =
          '${expense.date.year}-${expense.date.month}-${expense.date.day}';
      dailyExpenses[dateKey] = (dailyExpenses[dateKey] ?? 0) + expense.amount;
    }

    return dailyExpenses.entries.map((entry) {
      DateTime date = DateTime.parse(entry.key);
      return ChartData(date, entry.value);
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: onAddPressed,
          )
        ],
        backgroundColor: const Color.fromARGB(255, 106, 106, 106),
        title: const Text('Thida\'s Money Tracker'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Text(
              'Current Balance: \$${_currentBalance.toStringAsFixed(2)}',
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
          ),
          SizedBox(
            height: 200,
            child: SfCartesianChart(
              primaryXAxis: DateTimeAxis(),
              primaryYAxis: NumericAxis(),
              series: <ChartSeries>[
                ColumnSeries<ChartData, DateTime>(
                  dataSource: getChartData(),
                  xValueMapper: (ChartData data, _) => data.date,
                  yValueMapper: (ChartData data, _) => data.amount,
                  color: Colors.blue,
                ),
              ],
            ),
          ),
          Expanded(
            child: ExpensesList(
              expenses: _registeredExpenses,
              onExpenseRemoved: onExpenseRemoved,
            ),
          ),
        ],
      ),
    );
  }
}

class ChartData {
  final DateTime date;
  final double amount;

  ChartData(this.date, this.amount);
}
